#!/bin/bash

sudo apt install make gcc libx11-dev libxft-dev libxinerama-dev xorg git flameshot picom bash-completion xterm diodon arandr lxappearance libnotify4 notification-daemon libnotify-bin network-manager-gnome xautolock volumeicon-alsa kdeconnect pulseaudio vim feh thunar lightdm lightdm-gtk-greeter-settings libxrandr-dev 
